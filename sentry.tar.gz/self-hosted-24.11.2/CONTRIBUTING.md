## Testing

### Running Tests with Pytest

We use pytest for running tests. To run the tests:

1) Ensure that you are in the root directory of the project.
2) Run the following command:
```bash
pytest
```

This will automatically discover and run all test cases in the project.
