#!/usr/bin/env bash
cmd="restore $1"
source scripts/_lib.sh
$cmd
